<?php
/**
 * Created by PhpStorm.
 * User: Bidule
 * Date: 16/11/2017
 * Time: 15:58
 */

namespace app\classes;

class Config {

    public static function getPDO()
    {
        return [
            'hostname' => "localhost",
            'dbname' => "blog_ecrivain",
            'user' => "bidule",
            'password' => "261181"
        ];
    }
}



