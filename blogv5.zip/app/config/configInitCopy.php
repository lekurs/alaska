<?php
/**
 * Created by PhpStorm.
 * User: Bidule
 * Date: 16/11/2017
 * Time: 15:58
 */

namespace blog\app;


function logPdo()
{
    $logs = [
        'hotsname' => "",
        'dbname' => "",
        'user' => "",
        'password' => ""
    ];
    return $logs;
}