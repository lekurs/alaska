jQuery(document).ready(function ($) {

    $('.flash-notice_success').slideUp(2500);
    $('.flash-notice_error').slideUp(2500);

})